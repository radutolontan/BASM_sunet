#!/usr/bin/env python3
from PIL import Image
import numpy as np
import matplotlib
matplotlib.use("TkAgg")  # Use Tkinter backend for GUI display
import matplotlib.pyplot as plt

def discretize_image(image_path, x, y):
    # Open the image
    image = Image.open(image_path).convert("RGB")
    
    # Resize the image to the desired dimensions
    image_resized = image.resize((x, y), Image.Resampling.NEAREST)

    # Convert to NumPy array
    img_array = np.array(image_resized)

    return img_array

def visualize_matrix(matrix):
    plt.figure(figsize=(6, 6))
    plt.imshow(matrix)
    plt.axis("off")
    plt.title("Discretized Sunset Image")
    plt.show()

# Parameters
image_path = "sunset.jpg"  # Replace with your actual file path
x, y = 20, 20  # Adjust resolution as needed

# Process and visualize
matrix = discretize_image(image_path, x, y)
visualize_matrix(matrix)